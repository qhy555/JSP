package com.qhy.dao;


import com.qhy.bean.Shop;
import com.qhy.utils.JdbcUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ShopDao {
    Connection con = null;

    public boolean addShop(Shop shop) {
        boolean isSuccess = false;
        PreparedStatement psmt = null;
        String sql = "insert into shop values(null,?,?,?,?,?)";
        try {
            con = JdbcUtil.getConnecttion();
            psmt = con.prepareStatement(sql);
            psmt.setString(1, shop.getName());
            psmt.setDouble(2, shop.getPrice());
            psmt.setString(3, shop.getImg());
            psmt.setString(4, shop.getDescription());
            psmt.setInt(5, shop.getQuantity());
            psmt.executeUpdate();
            isSuccess = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.release(psmt, con);
        }
        return isSuccess;
    }

    public List<Shop> queryAllGoods() {
        List<Shop> list = new ArrayList<Shop>();
        PreparedStatement psmt = null;
        ResultSet rs = null;
        String sql = "SELECT * from shop";
        try {
            con = JdbcUtil.getConnecttion();
            psmt = con.prepareStatement(sql);
            rs = psmt.executeQuery();
            while (rs.next()) {
                Shop goods = new Shop();
                goods.setId(rs.getInt(1));
                goods.setName(rs.getString(2));
                goods.setPrice(rs.getDouble(3));
                goods.setImg(rs.getString(4));
                goods.setDescription(rs.getString(5));
                goods.setQuantity(rs.getInt(6));
                list.add(goods);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.release(rs, psmt, con);
        }
        return list;
    }

    public boolean deleteById(int id) {
        boolean isSuccess = false;
        PreparedStatement psmt = null;
        String sql = "delete from shop where id=?";
        try {
            con = JdbcUtil.getConnecttion();
            psmt = con.prepareStatement(sql);
            psmt.setInt(1, id);
            psmt.executeUpdate();
            isSuccess = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.release(psmt, con);
        }
        return isSuccess;
    }
}


