package com.qhy.bean;

public class Shop {
    private int id;
    private String name;
    private double price;
    private String img;
    private String description;
    private int quantity;

    public  Shop(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Shop( String name, double price, String img, String description, int quantity) {

        this.name = name;
        this.price = price;
        this.img = img;
        this.description = description;
        this.quantity = quantity;
    }

    public Shop(int anInt, String string, double aDouble, String rsString, String s, int rsInt) {
    }
}
