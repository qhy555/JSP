package com.qhy.servlet;

import com.google.gson.Gson;
import com.qhy.bean.Book;
import com.qhy.bean.Shop;
import com.qhy.dao.BookDao;
import com.qhy.dao.ShopDao;
import net.sf.json.JSONObject;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "ShoppingCartServlet",value = "/ShoppingCart")
public class ShoppingCartServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
//        int id = Integer.parseInt(request.getParameter("id"));
        ShopDao shopDao = new ShopDao();

        List list = shopDao.queryAllGoods();
        Gson gson = new Gson();
        request.setAttribute("goods", list);
//        shopDao.deleteById(id);

        RequestDispatcher rd = request.getRequestDispatcher("leading/shopping_cart.jsp");
        rd.forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
