package com.qhy.servlet;


import com.google.gson.Gson;
import com.qhy.dao.BookDao;
import com.qhy.dao.CateDao;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


@WebServlet(name = "Index",value ="/Index")
public class Index extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       //类型
        CateDao CateDao = new CateDao();
        List Catelist = CateDao.queryAllCates();
        //书本信息
        BookDao bookDao = new BookDao();
        List bookslist = bookDao.queryAllBooks();

        Gson booksgson = new Gson();

        Gson Categson = new Gson();
        String Catejson = Categson.toJson(Catelist);
        String bookgson = booksgson.toJson(bookslist);
        request.setAttribute("cateName", Catelist);
        request.setAttribute("books", bookslist);
        RequestDispatcher  requestDispatcher= request.getRequestDispatcher("leading/index.jsp");
        requestDispatcher.forward(request, response);

    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

}
