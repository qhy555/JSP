package com.qhy.servlet;


import com.qhy.bean.Shop;
import com.qhy.dao.ShopDao;
import net.sf.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

@WebServlet(name = "ShopServlet", urlPatterns = "/addShop")
public class ShopServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("addShop");   //判断请求业务层
//        int id = 0;
//        if (type.equals("addShop.do"))
           //int id = Integer.parseInt(request.getParameter("id")); //update业务需要指定id
        request.setCharacterEncoding("UTF-8");
        String name = request.getParameter("name");
        double price = Double.parseDouble(request.getParameter("price"));
        String img = request.getParameter("img");
        String description = request.getParameter("description");
        Integer quantity = Integer.valueOf(request.getParameter("quantity"));
        Shop shop = new Shop(name, price, img, description, quantity);
        ShopDao shopDao = new ShopDao();
        Map map = new HashMap();
        shopDao.addShop(shop);
        map.put("data", "添加成功！");
        //放回json到前端
        JSONObject msg = JSONObject.fromObject(map);
        PrintWriter out = response.getWriter();
        out.println(msg);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
